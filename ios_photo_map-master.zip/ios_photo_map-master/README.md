## Starter Project for Photo Map Exercise (Swift)
![Image](http://i.imgur.com/WIwqNtn.gif)

- Connects with Foursquare API
- Implements `LocationsViewController`
- Placeholders for `PhotoMapViewController` and `FullImageViewController`

    
